const mysql = require('mysql2/promise');

const {
  DB_HOST,
  DB_USER,
  DB_PASSWORD,
  DB_NAME,
} = process.env;

let pool;

function getPool() {
  if (!pool) {
    pool = mysql.createPool({
      host: DB_HOST,
      user: DB_USER,
      password: DB_PASSWORD,
      database: DB_NAME,
      waitForConnections: true,
      connectionLimit: 5,
      queueLimit: 0,
    });
  }
  return pool;
}

function parseEvent(event) {
  if (event.body) {
    try {
      return JSON.parse(event.body);
    } catch {
      // ignore
    }
  }
  return event;
}

function validateOwner(ownerId) {
  if (!ownerId || !/^[0-9a-f-]{36}$/i.test(ownerId)) {
    throw new Error('Invalid ownerId');
  }
}

function response(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type,Authorization',
      'Access-Control-Allow-Methods': 'POST,DELETE,OPTIONS',
    },
    body: JSON.stringify(body),
  };
}

exports.handler = async (event) => {
  try {
    const body = parseEvent(event);
    const {
      operation,
      ownerId,
      device,
      product_name,
      product_brand,
      product_expiry,   // "YYYY-MM-DD"
      images,
      product_barcode,
      id,
    } = body;

    validateOwner(ownerId);
    const tableName = `${ownerId}_new_kitchen`;
    const pool = getPool();

    // -------- VIEW --------
    if (operation === 'view') {
      if (!device) {
        return response(400, { message: 'Missing device for view' });
      }

      const sql = `
        SELECT
          _id AS id,
          _owner,
          _device,
          product_name,
          product_brand,
          product_expiry,
          images,
          product_barcode
        FROM \`${tableName}\`
        WHERE _owner = ? AND _device = ?
        ORDER BY _id DESC
      `;

      const [rows] = await pool.execute(sql, [ownerId, device]);

      return response(200, {
        message: 'Kitchen items fetched',
        items: rows,
      });
    }

    // -------- ADD --------
    if (operation === 'add') {
      if (!device || !product_name) {
        return response(400, { message: 'Missing required fields for add' });
      }

      const sql = `
        INSERT INTO \`${tableName}\`
          (_owner, _device, product_name, product_brand, product_expiry, images, product_barcode)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `;

      const [result] = await pool.execute(sql, [
        ownerId,
        device,
        product_name,
        product_brand || null,
        product_expiry || null,
        images || null,
        product_barcode || null,
      ]);

      return response(200, {
        message: 'Kitchen item added',
        insertId: result.insertId ?? null,
      });
    }

    // -------- REMOVE --------
    if (operation === 'remove') {
      let sql;
      let params;

      if (id) {
        sql = `DELETE FROM \`${tableName}\` WHERE _id = ? LIMIT 1`;
        params = [id];
      } else {
        if (!device || !product_barcode) {
          return response(400, {
            message: 'Provide either id or (device + product_barcode) to remove',
          });
        }
        sql = `
          DELETE FROM \`${tableName}\`
          WHERE _owner = ?
            AND _device = ?
            AND product_barcode = ?
          LIMIT 1
        `;
        params = [ownerId, device, product_barcode];
      }

      const [result] = await pool.execute(sql, params);
      return response(200, {
        message: 'Kitchen item removed',
        affectedRows: result.affectedRows,
      });
    }

    return response(400, { message: 'Invalid operation (use add/remove/view)' });
  } catch (err) {
    console.error(err);
    return response(500, { message: 'Internal server error', error: err.message });
  }
};
